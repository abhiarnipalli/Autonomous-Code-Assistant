#include "./lib/job.h"
#include "./lib/json-develop/single_include/nlohmann/json.hpp"
#include "./lib/json-develop/single_include/nlohmann/json_fwd.hpp"
#include <string>
#include <iostream>
#include <fstream>
using json = nlohmann::json;
using namespace std;

class CreateLLM : public Job{
public:
    static Job *CreateCreateLLM(){
        return new CreateLLM();
    }
    virtual void Execute() override{
        json json_data;
        ifstream file(LLM_Prompt);
        if (!file.is_open()){
            std::cerr << "Had an error opening file: " << std::endl;
        }
        try{
            file >> json_data;
        }
        catch (const std::exception &e){
            std::cerr << "Had an error parsing JSON: " << e.what() << std::endl;
        }
        file.close();
        std::string json_string = json_data.dump();
        WriteToFile(json_string);
        Calling_LLM();
        JobCompletedCallback();
    }
    void PassInPrompt_IP(const std::string &promptToPassIn, const std::string &ip_passed) override{
        LLM_Prompt = promptToPassIn;
        IP_add_var = ip_passed;
    }
    virtual void JobCompletedCallback() override{
        signalCompletion();
    }

private:
    std::string LLM_Prompt;
    std::string IP_add_var;
    std::string json_file_path = "./Data/json_file.txt";

    void Calling_LLM(){
        std::string command = "python3 ./Code/Call_LLM.py " + json_file_path;
        int result = system(command.c_str());
        if (result != 0){
            std::cerr << "Had an error executing Python script." << std::endl;
        }
    }
    void WriteToFile(string json_string){
        ofstream file(json_file_path);
        if (!file.is_open()){
            std::cerr << "Had an error opening file: " << std::endl;
        }
        file << json_string << endl;
        file.close();
    }
};