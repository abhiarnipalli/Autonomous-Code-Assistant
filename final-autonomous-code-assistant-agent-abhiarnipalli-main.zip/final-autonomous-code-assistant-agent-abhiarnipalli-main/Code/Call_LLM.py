import sys
sys.path.append('/Users/marcoszertuche/miniforge3/lib/python3.10/site-packages')

import json
from gpt4all import GPT4All
from openai import OpenAI

def runGPT4AllModel(modelName, prompt):
    try:
        # Initialize GPT4All model with the specified model name
        model = GPT4All(modelName)
        # Generate output based on the provided prompt
        output = model.generate(prompt).js
        return output
    except Exception as e:
        print("An error occurred:", e)
        return None
    
def runOpenAIModel(prompt):
    try:
        # Initialize OpenAI client with the API key
        client = OpenAI(
            api_key='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' 
        )

        # Create a chat completion using OpenAI API
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant designed to provide detailed explanations on the errors/warnings from code of the user. Example how you can fix them"},
                {"role": "user", "content": prompt}
            ]
        )
        # Extract the response message from OpenAI API
        response_message = response.choices[0].message.content
        return response_message
    except Exception as e:
        print("An error occurred:", e)
        return None
    
# C++ Prompt
input_sz = len(sys.argv)

if input_sz > 1:
    errors_prompt = sys.argv[1]
else:
    errors_prompt = "Default prompt if not provided"

# Read the contents of the file
with open(errors_prompt, 'r') as file:
    json_string = file.read()

json_object = json.loads(json_string)

final_output = []
for json_data in json_object:
    errors_list = json_data.get('errors', [])
    filePath = json_data.get('filePath', '')

    for error in errors_list:
        # Extract error details from the JSON data
        codeBlock = error.get('codeBlock', '')
        column = error.get('column', '')
        errorDescription = error.get('errorDescription', '')
        filePath = error.get('filePath', '')
        line = error.get('line', '')
        returnCode = error.get('returnCode', '')

        # Create a prompt for analysis including error details
        finalPrompt = "Provide a detailed description of the following errors and include an analysis of what should be done? Here are the errors: \n"
        finalPrompt += f"code: {codeBlock}; column: {column}; errorDescription: {errorDescription}; filePath: {filePath}; line: {line}; return code: {returnCode}"

        # Run GPT4All and OpenAI models with the final prompt
        GPT4All_Response = runGPT4AllModel('orca-mini-3b-gguf2-q4_0.gguf', finalPrompt)
        OpenAI_Response = runOpenAIModel(finalPrompt)
        
        # Append the results to the final output list
        final_output.append({
            "gpt4all_feedback": GPT4All_Response,
            "openai_feedback": OpenAI_Response,
            "json_object": json_data
        })

# Write the response to a JSON file
with open("./Data/response.json", "w") as output_file:
    json.dump(final_output, output_file)
print('Response File Created')
