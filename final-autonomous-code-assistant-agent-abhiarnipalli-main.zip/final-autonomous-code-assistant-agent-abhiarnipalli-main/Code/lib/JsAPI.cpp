#include <iostream>
#include <fstream>
#include "./JobSystem.h"
#include "./job.h"
#include "JsAPI.h"
#include "JobFactory.h"
#include "./json-develop/single_include/nlohmann/json.hpp"
#include "./json-develop/single_include/nlohmann/json_fwd.hpp"
using json = nlohmann::json;

JsAPI::JsAPI(){
    jsForAPI = JobSystem::CreateOrGet();
    jobFactory = new JobFactory();
}
JsAPI::~JsAPI(){
    delete jobFactory;
}
void JsAPI::getJobType(){
}
Job *JsAPI::getJob(const std::string &n_job){
    return jobsForAPI[n_job];
}
void JsAPI::destroyJob(const std::string &jobType){
    if (jobType == "CreateLLM"){
        std::cout << "Destroying CustomJob" << std::endl;
        delete jobsForAPI[jobType];
        jobsForAPI.erase(jobType);
    }
    else{
        std::cout << "invalid job type" << std::endl;
    }
}
void JsAPI::getJobStatus(const std::string &jobType){
    Job *job = jobsForAPI[jobType];
    if (jobType == "CreateLLM"){
        std::cout << "CreateLLM status: " << jsForAPI->GetJobStatus(job->GetUniqueID()) << std::endl;
    }
    else{
        std::cout << "invalid job type" << std::endl;
    }
}
void JsAPI::completeJob(const std::string &jobType){
    Job *job = jobsForAPI[jobType];
    if (jobType == "CreateLLM"){
        std::cout << "Completing CreateLLM" << std::endl;
        jsForAPI->FinishJob(job->GetUniqueID());
    }
    else{
        std::cout << "invalid job type" << std::endl;
    }
}
void JsAPI::startJobSystem(){
    jsForAPI->CreateWorkerThread("Thread1", 0xFFFFFFFF);
    jsForAPI->CreateWorkerThread("Thread2", 0xFFFFFFFF);
    jsForAPI->CreateWorkerThread("Thread3", 0xFFFFFFFF);
    jsForAPI->CreateWorkerThread("Thread4", 0xFFFFFFFF);
    jsForAPI->CreateWorkerThread("Thread5", 0xFFFFFFFF);
    jsForAPI->CreateWorkerThread("Thread6", 0xFFFFFFFF);
    jsForAPI->CreateWorkerThread("Thread7", 0xFFFFFFFF);
    jsForAPI->CreateWorkerThread("Thread8", 0xFFFFFFFF);

    for (const std::string &jobType : jobOrder){
        Job *job = jobsForAPI[jobType];
        std::promise<void> jobCompletionPromise;
        std::future<void> jobCompletionFuture = jobCompletionPromise.get_future();
        jsForAPI->QueueJob(job);
        std::unique_lock<std::mutex> lock(jobMutex);
        job->cv.wait(lock, [job]
                     { return job->condition; });
    }
}

void JsAPI::initialize(){
    jsForAPI->CreateWorkerThread("Thread1", 0xFFFFFFFF);
    jsForAPI->CreateWorkerThread("Thread2", 0xFFFFFFFF);
    jsForAPI->CreateWorkerThread("Thread3", 0xFFFFFFFF);
    jsForAPI->CreateWorkerThread("Thread4", 0xFFFFFFFF);
    jsForAPI->CreateWorkerThread("Thread5", 0xFFFFFFFF);
    jsForAPI->CreateWorkerThread("Thread6", 0xFFFFFFFF);
    jsForAPI->CreateWorkerThread("Thread7", 0xFFFFFFFF);
    jsForAPI->CreateWorkerThread("Thread8", 0xFFFFFFFF);
}

void JsAPI::queueJob(const std::string &m_job){
    Job *job = jobsForAPI[m_job];
    std::promise<void> jobCompletionPromise;
    std::future<void> jobCompletionFuture = jobCompletionPromise.get_future();
    jsForAPI->QueueJob(job);
    std::unique_lock<std::mutex> lock(jobMutex);
}

void JsAPI::setJobSystemObj(JsAPI *jobSystemObjPassedInFromMain){
    js = jobSystemObjPassedInFromMain;
}

void JsAPI::destroyJobSystem(){

    jsForAPI->Destroy();
}

void JsAPI::stopJobSystem(){
    jsForAPI->FinishCompletedJobs();
}

void JsAPI::dependency(const std::string &jobType1, const std::string &jobType2){
    std::vector<std::string> dependencies;
    dependencies.push_back(jobType1);
    dependencies.push_back(jobType2);
    for (const auto &job : jobOrder){
        if (std::find(dependencies.begin(), dependencies.end(), job) == dependencies.end()){
            dependencies.push_back(job);
        }
    }
    jobMutex.lock();
    jobOrder = dependencies;
    jobMutex.unlock();
    int ID = 0;
    for (const auto &jobType : jobOrder){
        Job *job = jobsForAPI[jobType];
        job->setUniqueID(ID);
        ID++;
    }
}

void JsAPI::createCustomJob(const std::string &jobType){
    Job *customJob = jobFactory->Create(jobType);
    if (customJob){
        jobsForAPI[jobType] = customJob;
        jobOrder.push_back(jobType);
    }
    else{
        std::cout << "Failed to create custom job: " << jobType << std::endl;
    }
}

void JsAPI::registerCustomJob(JobFactoryFunction factoryFunction, const std::string &jobTypeName){
    jobFactory->Register(factoryFunction, jobTypeName);
}