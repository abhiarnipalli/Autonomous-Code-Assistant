#pragma once
#include "./job.h"
#include <iostream>
#include "customjob.h"
#include "JsAPI.h"

class CustomJob : public Job{
public:
    void Execute() override;
    void SetFilePath(const std::string &path) { filePath = path; }
    void SetJobSystem(JsAPI *jobSystem) { jsForCJ = jobSystem; }
    void JobCompletedCallback() override;
    std::string output;
    int returnCode;
    static Job *CreateCustomJob();
    using JobCompletedCallbackType = std::function<void(const std::vector<std::string> &)>;
    JobCompletedCallbackType jobCompletedCallback;
    const std::vector<std::string> &getJobLabels() const{
        std::cout << "\n\n\nJOBLABELS HOLDS THIS: " << std::endl;
        for (const auto &labels : jobLabels){
            std::cout << labels << std::endl;
        }
        std::cout << "GETTING JOB LABELS" << std::endl;
        return jobLabels;
    }

private:
    std::map<std::string, Job *> jobsForAPIMap;
    std::string filePath;
    JsAPI *jsForCJ;
    std::vector<std::string> jobLabels;
};