#pragma once
#include <mutex>
#include <map>
#include <deque>
#include <vector>
#include <thread>
#include <iostream>
#include <condition_variable>

class Job {
    friend class JobSystem;
    friend class JobWorkerThread;
public:
    Job(unsigned long jobChannels = 0xFFFFFFFF, int jobType = -1) : m_jobChannels(jobChannels), m_jobType(jobType) {
        static int s_nextJobID = 0;
        m_jobID = s_nextJobID++;
    }
    virtual ~Job() {}
    virtual void Execute() = 0;
    virtual void JobCompletedCallback() {}
    virtual void PassInPrompt_IP(const std::string &promptToPassIn , const std::string &ip_address) {}
    int GetUniqueID() const { return m_jobID; }
    void setUniqueID(int id) { m_jobID = id; }
    void signalCompletion() {
        std::lock_guard<std::mutex> lock(jobMutex);
        condition = true;
        cv.notify_one();
    }
    std::condition_variable cv;
    bool condition = false;
private:
    int m_jobID = -1;
    int m_jobType = -1;
    std::mutex jobMutex;
    bool JobComplete = true;
    unsigned long m_jobChannels = 0xFFFFFFFF;
};