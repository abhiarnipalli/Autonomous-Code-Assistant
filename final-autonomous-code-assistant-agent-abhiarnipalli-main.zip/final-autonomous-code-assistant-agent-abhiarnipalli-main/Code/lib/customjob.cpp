#include "customjob.h"

Job *CustomJob::CreateCustomJob(){
    return new CustomJob();
}

void CustomJob::Execute(){
    std::cout << "CustomJob is executing!" << std::endl;
    JobCompletedCallback();
}

void CustomJob::JobCompletedCallback(){
    std::cout << "CustomJob callback is done!" << std::endl;
    signalCompletion();
}