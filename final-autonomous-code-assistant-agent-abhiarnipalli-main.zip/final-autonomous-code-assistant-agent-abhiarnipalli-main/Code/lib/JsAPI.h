#pragma once
#include <string>
#include <set>
#include <queue>
#include "./JobSystem.h"
#include <future>
#include "JobFactory.h"

class JsAPI{
private:
    JobSystem *jsForAPI = JobSystem::CreateOrGet();
    std::map<std::string, Job *> jobsForAPI;
    std::vector<std::string> jobOrder;
    std::mutex jobMutex;
    JsAPI *js;
    JobFactory *jobFactory;
public:
    JsAPI();
    ~JsAPI();
    void getJobType();
    Job* getJob(const std::string &n_job);
    void createJob(const std::string &n_job);
    void destroyJob(const std::string &n_job);
    void completeJob(const std::string &n_job);
    void getJobStatus(const std::string &n_job);
    void setJobSystemObj(JsAPI *jobSystemObjPassedInFromMain);
    void startJobSystem();
    void initialize();
    void queueJob(const std::string &n_job);
    void stopJobSystem();
    void destroyJobSystem();
    void dependency(const std::string &n_job1, const std::string &n_job2);
    void createCustomJob(const std::string &n_job);
    void registerCustomJob(JobFactoryFunction factoryFunction, const std::string &n_job);
};