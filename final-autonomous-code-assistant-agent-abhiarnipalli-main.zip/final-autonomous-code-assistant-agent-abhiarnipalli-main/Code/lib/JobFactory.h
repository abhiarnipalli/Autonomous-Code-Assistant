#pragma once
#include "./job.h"
#include <map>
#include <string>


class JsAPI;
typedef Job *(*JobFactoryFunction)();
class JobFactory{
public:
    void Register(JobFactoryFunction factoryFunction, const std::string &m_name);
    Job *Create(const std::string &m_name);
private:
    std::map<std::string, JobFactoryFunction> m_registeredJobs;
};