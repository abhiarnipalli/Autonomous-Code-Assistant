import express from 'express'
import { callLLM } from './openai.js'

const aplicationz = express()
const port = 3000

aplicationz.use(express.json())
aplicationz.get('/call-open-ai', async (req, res) => {
  const IP_addz = '103.234.2342'
  const user_propmt =
    'Smooth.h:63:15: error: invalid user-defined conversion from ‘Smooth<T, S>::sum(std::size_t) [with T = short unsigned int; long unsigned int S = 20; std::size_t = long unsigned int]::<lambda(short unsigned int, short unsigned int)>’ to ‘short unsigned int (*)(short unsigned int, short unsigned int)'
  try {
    const result = await callLLM({ IP: IP_addz, prompt: user_propmt })
    res.send(result)
  } catch (error) {
    console.error(error)
    res.status(500).send({ error: error.message })
  }
})

aplicationz.listen(port, () => {
  console.log(`Example app listening on http://localhost:${port}`)
})